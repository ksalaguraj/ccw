export const environment = {
    production: true,
	baseHref: '/',
    domainUrl: 'https://dev.careers.idp.com/',
    awsEndPointUrl: 'https://api.dev.careers.idp.com/careerCorporate/v1/contentful/get-contentful-data',
    xApiKey: 'GatUycHiZTah3HVpIXA4o2AJQGmsJkrH1dboQVIB'
};
