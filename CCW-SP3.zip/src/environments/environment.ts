// This file can be replaced during build by using the `fileReplacements` array.

// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.

// The list of file replacements can be found in `angular.json`.



//  export const environment = {

//     production: false,

//     baseHref: '/',

//     domainUrl: 'https://dev.careers.idp.com/',

//     awsEndPointUrl: 'https://api.dev.careers.idp.com/careerCorporate/v1/contentful/get-contentful-data',

//     xApiKey: 'GatUycHiZTah3HVpIXA4o2AJQGmsJkrH1dboQVIB'

// };



//stage

export const environment = {
    production: true,
    baseHref: '/',
    domainUrl: 'https://stg.careers.idp.com',
    awsEndPointUrl: 'https://api.stg.careers.idp.com/careerCorporate/v1/contentful/get-contentful-data',
    xApiKey: 'umu21kQm2H8Sv4K5a7yxp2ZYdvSktz9D5xRqAnN9'

};