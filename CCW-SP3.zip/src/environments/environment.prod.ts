export const environment = {
    production: true,
    baseHref: '/',
    domainUrl: 'https://www.careers.idp.com',
    awsEndPointUrl: 'https://api.careers.idp.com/careerCorporate/v1/contentful/get-contentful-data',
    xApiKey: 'Q6uDYwPH7FCpYy7RTsNc3Yl3CXJ7Gly4j5oybGh0'
    
};