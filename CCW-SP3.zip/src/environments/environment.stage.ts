export const environment = {
    production: true,
	baseHref: '/',
    domainUrl: 'https://stg.careers.idp.com',
    awsEndPointUrl: 'https://api.stg.careers.idp.com/careerCorporate/v1/contentful/get-contentful-data',
    xApiKey: 'umu21kQm2H8Sv4K5a7yxp2ZYdvSktz9D5xRqAnN9'
};
