export class ArticleLandingDetails {
    constructor(
      public  alBanner: Object = {},
      public  DynamicArticle: Array<object> = [],
      public  alBreadCrumb: Array<object> = [],
    ) {
    }
}