export class ContactDetails {
    constructor(
      public  contactBanner: Object = {},
    ) {
    }
}