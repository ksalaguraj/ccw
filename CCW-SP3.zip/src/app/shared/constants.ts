export const gtmConst = {
    eventName : {
        events: "Interaction"
    },
    category : {
        interaction: 'Interaction',
    },
    action : {
        cta: 'CTA'
    },
    label : {
         joinOurTeam: 'Join our team'
    }
};